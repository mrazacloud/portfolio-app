const Contact = require('../models/contact');

// Get all contacts
exports.getAllContacts = async (req, res) => {
    try {
        const contacts = await Contact.find();
        res.json(contacts);
    } catch (error) {
        res.status(500).send(error);
    }
};

// Get contact by ID
exports.getContactById = async (req, res) => {
    try {
        const contact = await Contact.findById(req.params.id);
        if (!contact) return res.status(404).send('Contact not found');
        res.json(contact);
    } catch (error) {
        res.status(500).send(error);
    }
};

// Add new contact
exports.addContact = async (req, res) => {
    const newContact = new Contact(req.body);
    try {
        await newContact.save();
        res.status(201).json(newContact);
    } catch (error) {
        res.status(400).send(error);
    }
};

// Update contact by ID
exports.updateContact = async (req, res) => {
    try {
        const updatedContact = await Contact.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!updatedContact) return res.status(404).send('Contact not found');
        res.json(updatedContact);
    } catch (error) {
        res.status(400).send(error);
    }
};

// Remove contact by ID
exports.removeContact = async (req, res) => {
    try {
        await Contact.findByIdAndDelete(req.params.id);
        res.status(204).send();
    } catch (error) {
        res.status(500).send(error);
    }
};

// Remove all contacts
exports.removeAllContacts = async (req, res) => {
    try {
        await Contact.deleteMany({});
        res.status(204).send();
    } catch (error) {
        res.status(500).send(error);
    }
};
