const User = require('../models/user');

// Get all users
exports.getAllUsers = async (req, res) => {
    const users = await User.find();
    res.json(users);
};

// Get user by ID
exports.getUserById = async (req, res) => {
    const user = await User.findById(req.params.id);
    res.json(user);
};

// Add new user
exports.addUser = async (req, res) => {
    const newUser = new User(req.body);
    await newUser.save();
    res.status(201).json(newUser);
};

// Update user by ID
exports.updateUser = async (req, res) => {
    const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedUser);
};

// Remove user by ID
exports.removeUser = async (req, res) => {
    await User.findByIdAndDelete(req.params.id);
    res.status(204).send();
};

// Remove all users
exports.removeAllUsers = async (req, res) => {
    await User.deleteMany({});
    res.status(204).send();
};
